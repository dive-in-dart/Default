// ignore_for_file: constant_identifier_names

enum AppPlatform {
  mobile,
  web,
}

enum GreekLicenseValidity {
  monthly,
  quarterly,
}

enum APINames {
  app_version,
  get_software_details,
  authenticate_user,
  get_cmember_code,
  send_otp,
  update_password,
  verify_otp,
  logout,
  select_company,

  login,
  refreshAT,
  getplanid,
  get_stock_flow_reports,
  get_global_reports,
  // get_global_report_from_date,
  // get_global_report_from_date_cd,
  ledger_reports_account_details,
  ledger_report_opening_balance,
  ledger_report_today,
  get_global_total_fields,
  get_global_grossPL,
  get_trial_balance,
  get_bo_gain_loss,
  get_cash_flow,

  // DASHBOARD
  getIndexData,
  sendPortfolioData,
  sendGroupMasterData,
  getDashboardData,
  getTopFiveStock,
  getDashboardBanks,
  getViewInvestmentReturn,
  getDashboardHeader,
  savePortfolioData,
  saveGroupMasterData,
  SelectPortfolioData,
  SelectGroupMasterData,
  EditPortfolioData,
  EditGroupMasterData,
  DeleteGroupMasterData,
  DeletePortfolioData,
  getStockDetailsReport,
  tab_management,
  add_transaction,
  getStkSaveData,
  transaction_data,
  getinsertinmap,
  getGroupMaster,
  insertGroupMaster,
  deleteGroupMaster,
  getAccountMaster,
  insertAccountMaster,
  updateAccountMaster,
  deleteAccountMaster,
  getStockHoldings,

//Sector
  getSectors,

  // Broker
  getSaveBrokerMaster,
  getUpdateBrokerMaster,
  getDeleteBrokerMaster,

  getSelectBrokerMaster,
  getSendBrokerMaster,

  // Branch
  getSaveBranchMaster,
  getUpdateBranchMaster,
  getDeleteBranchMaster,
  getSelectBranchMaster,
  getSendBranchMaster,

// Top Gainer Loser
  getTopGainers,
  getTopLosers,

  dummyApi,

  getVoucherCode,
  getAccountCode,
  getDividendCode,
  deleteVoucherDetails,
  getStkVoucherCode,
  getStkVoucherCodeFO,
  getSaveData,
  insertinDB,
  fetchopenpositiondata,
  uploadopenpositiondata,
  displayerrordata,
  displayerrordatapdf,
  getJVAccountCode,
  getJVSaveData,
  getStkScripNamePrvEquity,
  heartbeatrequest,
  getStkAccountCode,
  getStkScripName,
  getStkScripNameFO,
  reports_column,
  fetch_reports_column,
  getPortfolioAnalysis,
  stock_in_hand,
  gain_loss,
  getGainLossReport,

  voucher_details,
  SearchVoucherDetails,
  add_details,
  getBalance,
  getDayGlobal,
  getTotal,
  getStockInHand,
  getSelectColumnData,
  getUpdateColumnData,
  //voucher Report
  getDeleteVoucher,
  editvoucherreport,
  getTrailBalReport,
  getTrailDetailReport,
  getTrailBalanceTotal,
  getLedgerDetailTotal,

//IPO
  getStkVoucherCodeIPO,
  getStkScripNameIPO,
  getIPOSaveData,

  getBalancesheetSummary,
  getBalancesheetDetail,
  getBalanceSheetTotal,

//pnL
  getProfitLossSummary,
  getProfitLossDetail,
// ledgerReport
  getAccountDesc,
  getLedgerReport,
  getledgertradedetails,
  //Banks
  setDataInMap,
  editUpdatedData,
  saveUpdatedData,

  SearchStkDetails,

//Stocks
  getbrokers,
  getStkSaveDataFO,
  getGlobalReport,
  getRegisterUser,
  getverifyOTP,
  forgotpassword,
  validateLogin,
  getClientData,
  getCliFileStatus,
  getCAFile,
  //fd
  getFDSaveData,
  getFDPrevData,
  getSingleVoucherData,

  //Voucher Report
  getvoucherreport,
  //Precious Metal
  getMetalsSaveData,
  // Immovable property
  getIPropertiesSaveData,
  getSingleIPData,
  EditIPandMetalsData,
//CorporateAction
  getCAStocks,
  getCAStockQty,
  getCAInsertData,
  getCASelectData,
  saveCAData,
  deleteCAData,
  saveAllCorpAction,

  displayCAFileData,
  getDividentTotal,
  getStkPrvEquitySaveData,
  upload,

  // new report
  eqGainLossReport,
  cgritReport,
  downloadJVIMGFile,
  selectTickets,

  reconcilationReport,

  //view logs,
  sendAuditlogs,
  sendLogsVcodes,

  // delete files
  getentriesdata,
  deletefileupload,
}

enum APIErrorCode {
  success,
  noContent,
  faile,
  nodata,
  sqlConectionfaile,
  queryFaile,
  unauthorized,
  sessionRequired,
  requestTimeOut,
  internalServerError,
  invalidUser,
  invalidPassword,
  unknown,
}
