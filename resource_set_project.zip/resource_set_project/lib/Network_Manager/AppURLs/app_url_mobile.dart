import 'package:resource_set_project/Network_Manager/network_manager.dart';

String getBaseAPIUrl() {
  return NetworkURLs.currentURL;
}
