// ignore_for_file: avoid_web_libraries_in_flutter

import 'dart:html';
import 'package:flutter/foundation.dart';
import 'package:resource_set_project/Network_Manager/network_manager.dart';

String getBaseAPIUrl() {
  return (kReleaseMode)
      ? window.location.href.split('#').first
      : NetworkURLs.currentURL;
}
