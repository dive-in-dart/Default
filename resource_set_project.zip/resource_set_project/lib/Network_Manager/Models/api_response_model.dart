// ignore_for_file: avoid_web_libraries_in_flutter, constant_identifier_names, unused_field, avoid_print, non_constant_identifier_names

import "dart:convert";
import 'package:flutter/foundation.dart';
import 'package:encrypt/encrypt.dart' as aesceypto;
import 'package:resource_set_project/Extension_Enum/greek_extension.dart';
import 'package:tuple/tuple.dart';

import '../../Extension_Enum/greek_enum.dart';

class APIResponseModel {
  Response response;

  APIResponseModel({required this.response});

  factory APIResponseModel.fromBase64({
    required int apiNo,
    required APINames apiName,
    required Tuple3<String, aesceypto.Key, aesceypto.IV> encryptedData,
  }) {
    /*var base64DecodedData;

    if (NetworkConstants.isBase64Encoding) {
      base64DecodedData = utf8.decode(
        base64.decode(base64BodyData),
      );
    } else {
      base64DecodedData = base64BodyData;
    }*/

    // final base64DecodedData = base64BodyData;
    final base64DecodedData = encryptedData.item1.decryptASE256CDC(
      key: encryptedData.item2,
      iv: encryptedData.item3,
    );
    String date = DateTime.now().toString();

    if (kDebugMode) {
      print(
          "\n---------------$apiNo. Response - (${apiName.name})---(${date.toString()})------------\n${base64DecodedData.toString()}\n------------------------------------------------------------------------");
    }

    final jsonObj = json.decode(base64DecodedData.toString());
    final responseResult = jsonObj["response"];

    return APIResponseModel(
      response: Response.fromJSON(responseResult),
    );
  }
}

class Response {
  int? errorCode;
  Object? data;

  Response({
    required this.errorCode,
    required this.data,
  });

  //factory Response.fromJSON(Map<String, Object> json) {
  factory Response.fromJSON(Map json) {
    return Response(
      errorCode: int.tryParse(json["errorcode"]?.toString() ?? '-1'),
      data: json["data"],
    );
  }
}
