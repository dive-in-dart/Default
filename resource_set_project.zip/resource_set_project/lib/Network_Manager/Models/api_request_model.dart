// ignore_for_file: avoid_web_libraries_in_flutter, constant_identifier_names, unused_field, avoid_print, non_constant_identifier_names

import "dart:convert";
import 'package:flutter/foundation.dart';

import '../../Extension_Enum/greek_enum.dart';

class APIRequestModel {
  final Request _request;

  factory APIRequestModel.JSONFrom({
    required int apiNo,
    required APINames apiName,
    required Object? bodyData,
  }) {
    final obj = APIRequestModel(
      Request(
        data: bodyData,
      ),
    );

    String date = DateTime.now().toString();

    if (kDebugMode) {
      print(
          '\n---------------$apiNo. Request - (${apiName.name})---(${date.toString()})------------\n${obj.jsonString()}\n------------------------------------------------------------------------');
    }

    return obj;
  }

  APIRequestModel(this._request);

  Object toJson() => {
        "request": _request.toJson(),
      };

  String jsonString() {
    final s1 = json.encode(toJson());
    return s1;
  }

  String base64Body() {
    /*if (NetworkConstants.isBase64Encoding)
      return base64.encode(utf8.encode(this.jsonString()));
    else
      return this.jsonString();*/

    return jsonString();
  }
}

class Request {
  final Object? data;

  Request({required this.data});

  Object? toJson() {
    final dic = {
      "data": (data == null) ? {} : data,
    };

    return dic;
  }
}
