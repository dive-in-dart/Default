// ignore_for_file: avoid_web_libraries_in_flutter, constant_identifier_names, unused_field, avoid_print, use_build_context_synchronously

import 'dart:math' as io_math;
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import "package:http/http.dart" as http;
import 'package:encrypt/encrypt.dart' as aesceypto;
import 'package:resource_set_project/Extension_Enum/greek_extension.dart';
import 'package:resource_set_project/Helper/greek_base.dart';
import 'package:tuple/tuple.dart';
import '../Configuration/app_config.dart';
import '../Extension_Enum/greek_enum.dart';
import '../Utilities/greek_dialog_popup_view.dart';
import 'AppURLs/app_url_main.dart';
import 'Models/api_request_model.dart';
import 'Models/api_response_model.dart';

class NetworkURLs {
  static const _local_host = 'http://192.168.209.233:4446/'; // Aditya node

  static const currentURL = _local_host;
}

class NetworkManager {
  final _baseURL = getBaseAPIUrl();

  static bool _isValidToken = true;

  final BuildContext _networkContext;
  NetworkManager(this._networkContext);
  static NetworkManager of(BuildContext networkContext) {
    return NetworkManager(networkContext);
  }

  void _hideAppLoader() {
    if (GreekBase().loaderContext != null) {
      Navigator.of(GreekBase().loaderContext!).pop();
      GreekBase().loaderContext = null;
    }
  }

  Future<Object?> authenticateUser({
    required String user,
    required String password,
  }) async {
    _isValidToken = true;

    final apiNo = io_math.Random().nextInt(999);

    final jsonString = APIRequestModel.JSONFrom(
      apiNo: apiNo,
      apiName: APINames.authenticate_user,
      bodyData: {
        "user_name": user,
        "password": password,
      },
    ).jsonString();
    final encryptedDataTuple = jsonString.encryptASE256CDC();

    Map<String, String>? headers = {
      "publickey": encryptedDataTuple.item2,
      "publiciv": encryptedDataTuple.item3,
    };

    try {
      final loginAPIClient = http.Client();
      final response = await loginAPIClient.post(
        Uri.parse(_baseURL + APINames.authenticate_user.name),
        headers: headers,
        body: encryptedDataTuple.item1,
      );
      loginAPIClient.close();

      final statusCode = response.statusCode.intToApiErrorCode();

      switch (statusCode) {
        case APIErrorCode.success:
          final obj = APIResponseModel.fromBase64(
            apiNo: apiNo,
            apiName: APINames.authenticate_user,
            encryptedData: Tuple3<String, aesceypto.Key, aesceypto.IV>(
              response.body,
              encryptedDataTuple.item4,
              encryptedDataTuple.item5,
            ),
          );

          return obj.response.data;

        case APIErrorCode.noContent:
        case APIErrorCode.faile:
        case APIErrorCode.nodata:
        case APIErrorCode.sqlConectionfaile:
        case APIErrorCode.queryFaile:
          _isValidToken = true;
          return null;

        case APIErrorCode.unauthorized:
          return null;

        case APIErrorCode.sessionRequired:
          return null;

        case APIErrorCode.requestTimeOut:
          _hideAppLoader();

          _isValidToken = true;

          GreekDialogPopupView.awesomeMessageDialog(
            context: _networkContext,
            msg: 'Request time out',
            dialogType: DialogType.error,
            onPressed: (_) {},
          );
          return null;

        case APIErrorCode.internalServerError:
          return null;

        case APIErrorCode.unknown:
          _hideAppLoader();

          _isValidToken = true;

          GreekDialogPopupView.awesomeMessageDialog(
            context: _networkContext,
            msg: 'Something went wrong...',
            dialogType: DialogType.error,
            onPressed: (_) {},
          );
          return null;
        case APIErrorCode.invalidUser:
          return null;

        case APIErrorCode.invalidPassword:
          return null;
      }
    } catch (exception) {
      print(
          '\n---------------$apiNo. API Exception - (${APINames.authenticate_user.name})---------------\n${exception.toString()}\n------------------------------------------------------------------------');

      _hideAppLoader();

      GreekDialogPopupView.awesomeMessageDialog(
        context: _networkContext,
        msg: 'Could not connect to server, Try again',
        dialogType: DialogType.warning,
        onPressed: (_) {},
      );

      return null;
    }
  }

  Future<Object?> postAPI({
    required APINames apiName,
    required dynamic postBodyData,
  }) async {
    if (_isValidToken) {
      _isValidToken = (apiName != APINames.logout);

      final apiNo = io_math.Random().nextInt(999);

      final jsonString = APIRequestModel.JSONFrom(
        apiNo: apiNo,
        apiName: apiName,
        bodyData: postBodyData,
      ).jsonString();

      final encryptedDataTuple = jsonString.encryptASE256CDC();

      Map<String, String>? headers = {
        'auth-user-id': AppConfig().loginId.toString(),
        'publicKEY': encryptedDataTuple.item2,
        'publicIV': encryptedDataTuple.item3,
      };

      // if (AppConfig().token.isNotEmpty) {
      //   headers['authorization'] = "Bearer ${AppConfig().token}";
      // }

      try {
        final postAPIClient = http.Client();
        final response = await postAPIClient.post(
          Uri.parse(_baseURL + apiName.name),
          headers: headers,
          body: encryptedDataTuple.item1,
        );
        postAPIClient.close();

        final statusCode = response.statusCode.intToApiErrorCode();

        switch (statusCode) {
          case APIErrorCode.success:
            final obj = APIResponseModel.fromBase64(
              apiNo: apiNo,
              apiName: apiName,
              encryptedData: Tuple3<String, aesceypto.Key, aesceypto.IV>(
                response.body,
                encryptedDataTuple.item4,
                encryptedDataTuple.item5,
              ),
            );

            return obj.response.data;

          case APIErrorCode.nodata:
            return null;

          case APIErrorCode.noContent:
          case APIErrorCode.faile:
          case APIErrorCode.sqlConectionfaile:
          case APIErrorCode.queryFaile:
            _isValidToken = true;
            return null;

          case APIErrorCode.unauthorized:
            _hideAppLoader();

            _isValidToken = false;

            return null;

          case APIErrorCode.sessionRequired:
            _hideAppLoader();

            _isValidToken = false;

            return null;

          case APIErrorCode.requestTimeOut:
            _hideAppLoader();

            _isValidToken = true;

            GreekDialogPopupView.awesomeMessageDialog(
              context: _networkContext,
              msg: 'Request time out',
              dialogType: DialogType.error,
              onPressed: (_) {},
            );
            return null;

          case APIErrorCode.internalServerError:
            return null;

          case APIErrorCode.unknown:
            return null;
          case APIErrorCode.invalidUser:
            break;
          case APIErrorCode.invalidPassword:
            break;
        }
      } catch (exception) {
        print(
            '\n---------------$apiNo. API Exception - (${apiName.name})---------------\n${exception.toString()}\n------------------------------------------------------------------------');

        _hideAppLoader();

        GreekDialogPopupView.awesomeMessageDialog(
          context: _networkContext,
          msg: 'Could not connect to server, Try again',
          dialogType: DialogType.warning,
          onPressed: (_) {},
        );

        return null;
      }
    }

    return null;
  }
}
