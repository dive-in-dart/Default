// ignore_for_file: file_names, constant_identifier_names, non_constant_identifier_names, avoid_web_libraries_in_flutter

import 'dart:html' as html;
import 'dart:io' show Platform;
import 'package:resource_set_project/Extension_Enum/greek_enum.dart';
import 'package:encrypt/encrypt.dart';
import 'package:flutter/foundation.dart' show kIsWeb;

import 'package:intl/intl.dart';

class AppConfig {
  // Singleton object
  // static AppConfig _singleton = AppConfig._internal();
  static AppConfig? _singleton;

  factory AppConfig() {
    //return _singleton;
    if (_singleton == null) {
      _singleton = AppConfig._internal();
      return _singleton!;
    } else {
      return _singleton!;
    }
  }

  AppConfig._internal() {
    if (kIsWeb) {
      currentPlatform = AppPlatform.web;
    } else {
      if ((Platform.isIOS) || (Platform.isAndroid)) {
        currentPlatform = AppPlatform.mobile;
      }
    }
  }

  /// Encrypt data using AES encryption

  static const String _key = "3gT5bM8pQz6XaYvK2r9NsD1UwL7CfEjZ"; // 32 chars
  static const String _iv = "1A2B3C4D5E6F7G8H";
  // get selectedGrpPortexcel => null; // 16 chars

  String selectedGrpPortexcel = "";
  static String encryptData(String plainText) {
    if (plainText.isEmpty) return '';

    final key = Key.fromUtf8(_key);
    final iv = IV.fromUtf8(_iv);
    final encrypter = Encrypter(AES(key));

    return encrypter.encrypt(plainText, iv: iv).base64;
  }

  /// Decrypt data using AES decryption
  static String decryptData(String encryptedText) {
    // FIX: Return empty if input is empty or too short
    if (encryptedText.isEmpty) return '';

    try {
      final key = Key.fromUtf8(_key);
      final iv = IV.fromUtf8(_iv);
      final encrypter = Encrypter(AES(key));

      return encrypter.decrypt(Encrypted.fromBase64(encryptedText), iv: iv);
    } catch (e) {
      return '';
    }
  }

  // GLOBAL SESSION STORAGE
  void saveSessoionData(String key, String value) {
    html.window.sessionStorage[key] = encryptData(value);
  }

  String getSessoionData(String key) {
    String? rawValue = html.window.sessionStorage[key];

    // FIX: Check for null properly instead of .toString()
    if (rawValue == null || rawValue.isEmpty) {
      return "";
    }

    return decryptData(rawValue);
  }
  //===========================================================================
  // APP STATE VARIABLES
  //===========================================================================

  String appName = 'G Asset Pulse';
  int loginId = 0;

  AppPlatform currentPlatform = AppPlatform.web;

  String url = 'http://192.168.209.233:4498/';

  NumberFormat numberFormat = NumberFormat.decimalPattern('en_us');

  void disposeAppconfig() {
    _singleton = null;
  }
}
