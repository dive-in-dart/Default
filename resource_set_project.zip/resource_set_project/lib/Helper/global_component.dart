class GlobalComponent {
  // Singleton object
  static final GlobalComponent _singleton = GlobalComponent._internal();
  factory GlobalComponent() {
    return _singleton;
  }

  GlobalComponent._internal();

  //
}
