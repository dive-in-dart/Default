import 'package:flutter/material.dart';

class ConstantColors {
  static const transparentColor = Colors.transparent;
  static const whiteColor = Colors.white;
  static const blackColor = Colors.black;
  static const loginBorderColor = Color(0xFFECECEC);
  static const loginTextfieldBorderColor = Color(0xFFE5E5E5);
  static final loginTextfieldBGColor = Colors.grey.shade100;
  static const loginProceedButtonBGColor = Color(0xFF3380D9);
  static const loginProceedButtonShadowColor = Color.fromRGBO(0, 0, 0, 0.16);
  static const orangeColor = Color(0xFFF58634);
  static const blueColor = Color(0xFF3380D9);
  static const loginHintTextColor = Color.fromRGBO(68, 68, 68, 0.5);
  static const loginHintTextColor_2 = Color.fromARGB(120, 51, 51, 51);
  static const loginTextColor = Color(0xFF444444);
  static const loginProceedButtonTextColor = Color(0xFF444444);
  static const dataTableBorderColor = Color(0xFFB2B2B2);
  static const dataTableHeadingBGColor = Color.fromRGBO(242, 242, 242, 1.0);
  static const dataTableTextfieldBGColor = Color.fromRGBO(248, 248, 248, 1.0);
  static const dataTableTextfieldBorderColor =
      Color.fromRGBO(233, 233, 233, 1.0);
  static const goBackBorderColor = Color(0xFF1592E6);
  static const goBackBGColor = Color(0xFFF6F6F6);
  static const goBackTextColor = Color(0xFFF58634);
  static const dashboardUserNameShadowColor = Color.fromRGBO(0, 0, 0, 0.11);
  static const dashboardMenuShadowColor = Color.fromRGBO(7, 148, 255, 0.12);
  static const disableTableColumnBGColor = Color(0xFFF6F6F6);

  static const scaffoldBackgroundColor = Colors.white;
  static const primaryColor = Colors.white;
  static const cardTheme = Colors.white;
  static const primaryColorLight = Colors.lightBlue;
  static const primaryColorDark = Colors.blueAccent;
  static const canvasColor = Colors.white;
  static const accentColor = Colors.white;
  static const bottomAppBarColor = Colors.blueAccent;
  static const cardColor = Colors.white;

  static const dividerColor = Color(0xFFA1A1A1);
  static const focusColor = Colors.blueAccent;
  static const colorsSchemePrimary = Colors.white;
  static const onPrimary = Colors.white;
  static const primaryVariant = Colors.white;
  static const secondary = Colors.white;
  static const buyColor = Color(0xFF00CC33);
  static const sellColor = Color(0xFFFF0000);
  static const borderColor = Color(0x7CAFAFAF);
  static const watchlistText = Color(0xFF707070);
  static const marketText = Color(0xFF333333);

  static const searchSymbolPlaceHolderColor = Color(0xFF707070);
}
