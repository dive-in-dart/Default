// ignore_for_file: invalid_use_of_protected_member, invalid_use_of_visible_for_testing_member, depend_on_referenced_packages, avoid_web_libraries_in_flutter

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class GreekBase {
  //  For Loader
  BuildContext? loaderContext;

  // Singleton object
  static final GreekBase _singleton = GreekBase._internal();
  factory GreekBase() {
    return _singleton;
  }

  GreekBase._internal();

  double screenWidth = 0.0;

  bool isWeb = false;
  void getScreenSize(double screenW, bool isOld) {
    if (isOld) {
      if ((screenW - 100) < 1480) {
        screenWidth = 1480;
      } else {
        screenWidth = (screenW - 100);
      }
    } else {
      if (screenW < 1480) {
        screenWidth = 1480;
      } else {
        screenWidth = screenW;
      }
    }
    if (kDebugMode) {
      print("Screennnn widthh $screenWidth || 0");
    }
  }

  String getImagePath({required String imageName}) =>
      'lib/Resources/Images/$imageName';
  String getJSONFilePath({required String jsonFileName}) =>
      'lib/Resources/JSONs/$jsonFileName';

  void clearImageCache() {
    imageCache.clear();
    imageCache.clearLiveImages();
  }
}
