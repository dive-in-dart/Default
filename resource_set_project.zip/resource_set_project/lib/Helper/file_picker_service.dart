import 'package:file_picker/file_picker.dart';

class FilePickerService {
  static const List<String> defaultExtensions = ['jpg', 'jpeg', 'png', 'pdf'];

  static Future<PlatformFile?> pickFile({
    List<String>? allowedExtensions,
    double maxSizeMB = 1,
  }) async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: allowedExtensions ?? defaultExtensions,
      withData: true, // Important for web
    );

    if (result == null || result.files.isEmpty) return null;

    final file = result.files.first;

    final extension = file.extension?.toLowerCase() ?? "";
    final allowed = (allowedExtensions ?? defaultExtensions)
        .map((e) => e.toLowerCase())
        .toList();

    if (!allowed.contains(extension)) {
      throw Exception("Invalid file format");
    }

    final sizeInMB = file.size / (1024 * 1024);

    if (sizeInMB > maxSizeMB) {
      throw Exception("File must be less than $maxSizeMB MB");
    }

    return file;
  }
}
