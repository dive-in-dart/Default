/* // ignore_for_file: overridden_fields

import 'package:flutter/material.dart';

class SearchInputDecoration extends InputDecoration {
  /// text capitalization defaults to [TextCapitalization.none]
  final TextCapitalization textCapitalization;

  /// Specifies [TextStyle] for search input.
  final TextStyle? searchStyle;

  /// The color of the cursor.
  /// The cursor indicates the current location of text insertion point in the field.
  /// If this is null it will default to the ambient DefaultSelectionStyle.cursorColor. If that is
  /// null, and the ThemeData.platform is TargetPlatform.iOS or TargetPlatform.macOS it will use
  /// CupertinoThemeData.primaryColor. Otherwise it will use the value of ColorScheme.primary of
  /// ThemeData.colorScheme.
  ///
  final Color cursorColor;

  ///Creates a [FormField] that contains a [TextField].

  /// The color of the cursor when the InputDecorator is showing an error.
  ///
  /// If this is null it will default to TextStyle.color of InputDecoration.errorStyle. If that is
  /// null, it will use ColorScheme.error of ThemeData.colorScheme.
  ///
  final Color? cursorErrorColor;

  /// How tall the cursor will be.
  ///
  /// If this property is null, RenderEditable.preferredLineHeight will be used.
  final double? cursorHeight;

  /// How thick the cursor will be.
  /// Defaults to 2.0.
  /// The cursor will draw under the text. The cursor width will extend to the right of the
  /// boundary between characters for left-to-right text and to the left for right-to-left text.
  /// This corresponds to extending downstream relative to the selected position. Negative values
  /// may be used to reverse this behavior.
  ///
  final double? cursorWidth;

  /// Whether the cursor will animate from fully transparent to fully opaque during each cursor
  /// blink.
  /// By default, the cursor opacity will animate on iOS platforms and will not animate on Android /
  /// platforms.
  ///
  final bool? cursorOpacityAnimates;

  /// The radius of the cursor.How rounded the corners of the cursor should be.
  /// By default, the cursor has no radius.
  ///
  final Radius? cursorRadius;

  /// The appearance of the keyboard.
  /// This setting is only honored on iOS devices.
  ///
  /// If unset, defaults to ThemeData.brightness.
  ///
  final Brightness? keyboardAppearance;
  /////
  @override
  final InputBorder? border;
  @override
  final BoxConstraints? prefixIconConstraints;
  @override
  final int? errorMaxLines;
  @override
  final TextStyle? errorStyle;
  @override
  final String? errorText;
  @override
  final Color? fillColor;
  @override
  final bool? filled;
  @override
  final FloatingLabelAlignment? floatingLabelAlignment;
  @override
  final FloatingLabelBehavior? floatingLabelBehavior;
  @override
  final TextStyle? floatingLabelStyle;
  @override
  final Color? focusColor;
  @override
  final InputBorder? focusedBorder;
  @override
  final InputBorder? focusedErrorBorder;
  final Widget? helper;
  @override
  final int? helperMaxLines;
  @override
  final TextStyle? helperStyle;
  @override
  final String? helperText;
  final Duration? hintFadeDuration;
  @override
  final int? hintMaxLines;
  @override
  final TextStyle? hintStyle;
  @override
  final String? hintText;
  @override
  final TextDirection? hintTextDirection;
  @override
  final Color? hoverColor;
  @override
  final Widget? icon;
  @override
  final Color? iconColor;
  final bool? isCollapse;
  @override
  final bool? isDense;
  @override
  final Widget? label;
  @override
  final TextStyle? labelStyle;
  @override
  final String? labelText;
  @override
  final bool maintainHintHeight;
  @override
  final Widget? prefix;
  @override
  final Widget? prefixIcon;
  @override
  final Color? prefixIconColor;
  @override
  final TextStyle? prefixStyle;
  @override
  final String? prefixText;
  @override
  final String? semanticCounterText;
  @override
  final Widget? suffix;
  @override
  final Widget? suffixIcon;
  @override
  final Color? suffixIconColor;
  @override
  final BoxConstraints? suffixIconConstraints;
  @override
  final TextStyle? suffixStyle;
  @override
  final String? suffixText;
  @override
  final InputBorder? enabledBorder;
  @override
  final Widget? error;
  @override
  final InputBorder? errorBorder;
  @override
  final bool? alignLabelWithHint;
  @override
  final TextStyle? counterStyle;
  @override
  final String? counterText;
  @override
  final InputBorder? disabledBorder;
  @override
  final EdgeInsetsGeometry? contentPadding;
  @override
  final Widget? counter;
  @override
  final BoxConstraints? constraints;

  const SearchInputDecoration({
    //Key? key,
    this.cursorColor = Colors.black,
    this.textCapitalization = TextCapitalization.none,
    this.searchStyle,
    this.cursorErrorColor,
    this.cursorHeight,
    this.cursorWidth = 2.0,
    this.cursorOpacityAnimates,
    this.cursorRadius,
    this.keyboardAppearance,
    this.border,
    this.prefixIconConstraints,
    this.hintMaxLines,
    this.floatingLabelStyle,
    this.errorText,
    this.error,
    this.hintTextDirection,
    this.hintFadeDuration,
    this.helper,
    this.prefixIcon,
    this.suffixIcon,
    this.suffix,
    this.label,
    this.maintainHintHeight = true,
    this.suffixIconColor,
    this.prefix,
    this.prefixIconColor,
    this.enabledBorder,
    this.focusedBorder,
    this.errorBorder,
    this.focusedErrorBorder,
    this.disabledBorder,
    this.contentPadding,
    this.hintText,
    this.hintStyle,
    this.labelText,
    this.labelStyle,
    this.prefixText,
    this.prefixStyle,
    this.suffixText,
    this.suffixStyle,
    this.counterText,
    this.counterStyle,
    this.filled,
    this.fillColor,
    this.focusColor,
    this.hoverColor,
    this.icon,
    this.iconColor,
    this.isCollapse,
    this.isDense,
    this.floatingLabelBehavior,
    this.floatingLabelAlignment,
    this.alignLabelWithHint,
    this.constraints,
    this.counter,
    this.semanticCounterText,
    this.helperText,
    this.helperStyle,
    this.helperMaxLines,
    this.errorMaxLines,
    this.errorStyle,
    this.suffixIconConstraints,
  });

   @override
  SearchInputDecoration copyWith({
    Color? cursorColor,
    Color? cursorErrorColor,
    double? cursorHeight,
    double? cursorWidth,
    bool? cursorOpacityAnimates,
    Radius? cursorRadius,
    Brightness? keyboardAppearance,
    TextCapitalization? textCapitalization,
    TextStyle? searchStyle,
    bool? alignLabelWithHint,
    InputBorder? border,
    BoxConstraints? constraints,
    EdgeInsetsGeometry? contentPadding,
    Widget? counter,
    TextStyle? counterStyle,
    String? counterText,
    InputBorder? disabledBorder,
    InputBorder? enabledBorder,
    Widget? error,
    InputBorder? errorBorder,
    int? errorMaxLines,
    TextStyle? errorStyle,
    String? errorText,
    Color? fillColor,
    bool? filled,
    FloatingLabelAlignment? floatingLabelAlignment,
    FloatingLabelBehavior? floatingLabelBehavior,
    TextStyle? floatingLabelStyle,
    Color? focusColor,
    InputBorder? focusedBorder,
    InputBorder? focusedErrorBorder,
    Widget? helper,
    int? helperMaxLines,
    TextStyle? helperStyle,
    String? helperText,
    Duration? hintFadeDuration,
    int? hintMaxLines,
    TextStyle? hintStyle,
    String? hintText,
    TextDirection? hintTextDirection,
    Color? hoverColor,
    Widget? icon,
    Color? iconColor,
    bool? isCollapsed,
    bool? isDense,
    Widget? label,
    TextStyle? labelStyle,
    String? labelText,
    bool? maintainHintSize, // ✅ Flutter 3.32.7
    Widget? prefix,
    Widget? prefixIcon,
    Color? prefixIconColor,
    BoxConstraints? prefixIconConstraints,
    TextStyle? prefixStyle,
    String? prefixText,
    String? semanticCounterText,
    Widget? suffix,
    Widget? suffixIcon,
    Color? suffixIconColor,
    BoxConstraints? suffixIconConstraints,
    TextStyle? suffixStyle,
    String? suffixText,
  }) {
    return SearchInputDecoration(
      cursorColor: cursorColor ?? this.cursorColor,
      cursorErrorColor: cursorErrorColor ?? this.cursorErrorColor,
      cursorHeight: cursorHeight ?? this.cursorHeight,
      cursorWidth: cursorWidth ?? this.cursorWidth,
      cursorOpacityAnimates: cursorOpacityAnimates ?? this.cursorOpacityAnimates,
      cursorRadius: cursorRadius ?? this.cursorRadius,
      keyboardAppearance: keyboardAppearance ?? this.keyboardAppearance,
      textCapitalization: textCapitalization ?? this.textCapitalization,
      searchStyle: searchStyle ?? this.searchStyle,
      alignLabelWithHint: alignLabelWithHint ?? this.alignLabelWithHint,
      border: border ?? this.border,
      constraints: constraints ?? this.constraints,
      contentPadding: contentPadding ?? this.contentPadding,
      counter: counter ?? this.counter,
      counterStyle: counterStyle ?? this.counterStyle,
      counterText: counterText ?? this.counterText,
      disabledBorder: disabledBorder ?? this.disabledBorder,
      enabledBorder: enabledBorder ?? this.enabledBorder,
      error: error ?? this.error,
      errorBorder: errorBorder ?? this.errorBorder,
      errorMaxLines: errorMaxLines ?? this.errorMaxLines,
      errorStyle: errorStyle ?? this.errorStyle,
      errorText: errorText ?? this.errorText,
      fillColor: fillColor ?? this.fillColor,
      filled: filled ?? this.filled,
      floatingLabelAlignment: floatingLabelAlignment ?? this.floatingLabelAlignment,
      floatingLabelBehavior: floatingLabelBehavior ?? this.floatingLabelBehavior,
      floatingLabelStyle: floatingLabelStyle ?? this.floatingLabelStyle,
      focusColor: focusColor ?? this.focusColor,
      focusedBorder: focusedBorder ?? this.focusedBorder,
      focusedErrorBorder: focusedErrorBorder ?? this.focusedErrorBorder,
      helper: helper ?? this.helper,
      helperMaxLines: helperMaxLines ?? this.helperMaxLines,
      helperStyle: helperStyle ?? this.helperStyle,
      helperText: helperText ?? this.helperText,
      hintFadeDuration: hintFadeDuration ?? this.hintFadeDuration,
      hintMaxLines: hintMaxLines ?? this.hintMaxLines,
      hintStyle: hintStyle ?? this.hintStyle,
      hintText: hintText ?? this.hintText,
      hintTextDirection: hintTextDirection ?? this.hintTextDirection,
      hoverColor: hoverColor ?? this.hoverColor,
      icon: icon ?? this.icon,
      iconColor: iconColor ?? this.iconColor,
      isCollapse: isCollapsed ?? this.isCollapse,
      isDense: isDense ?? this.isDense,
      label: label ?? this.label,
      labelStyle: labelStyle ?? this.labelStyle,
      labelText: labelText ?? this.labelText,
      maintainHintSize: maintainHintSize ?? this.maintainHintSize, // ✅ Important
      prefix: prefix ?? this.prefix,
      prefixIcon: prefixIcon ?? this.prefixIcon,
      prefixIconColor: prefixIconColor ?? this.prefixIconColor,
      prefixIconConstraints: prefixIconConstraints ?? this.prefixIconConstraints,
      prefixStyle: prefixStyle ?? this.prefixStyle,
      prefixText: prefixText ?? this.prefixText,
      semanticCounterText: semanticCounterText ?? this.semanticCounterText,
      suffix: suffix ?? this.suffix,
      suffixIcon: suffixIcon ?? this.suffixIcon,
      suffixIconColor: suffixIconColor ?? this.suffixIconColor,
      suffixIconConstraints: suffixIconConstraints ?? this.suffixIconConstraints,
      suffixStyle: suffixStyle ?? this.suffixStyle,
      suffixText: suffixText ?? this.suffixText,
    );
  } 
}
 */

// ignore_for_file: overridden_fields

import 'package:flutter/material.dart';

class SearchInputDecoration extends InputDecoration {
  /// text capitalization defaults to [TextCapitalization.none]
  final TextCapitalization textCapitalization;

  /// Specifies [TextStyle] for search input.
  final TextStyle? searchStyle;

  /// The color of the cursor.
  /// The cursor indicates the current location of text insertion point in the field.
  /// If this is null it will default to the ambient DefaultSelectionStyle.cursorColor. If that is
  /// null, and the ThemeData.platform is TargetPlatform.iOS or TargetPlatform.macOS it will use
  /// CupertinoThemeData.primaryColor. Otherwise it will use the value of ColorScheme.primary of
  /// ThemeData.colorScheme.
  ///
  final Color cursorColor;

  ///Creates a [FormField] that contains a [TextField].

  /// The color of the cursor when the InputDecorator is showing an error.
  ///
  /// If this is null it will default to TextStyle.color of InputDecoration.errorStyle. If that is
  /// null, it will use ColorScheme.error of ThemeData.colorScheme.
  ///
  final Color? cursorErrorColor;

  /// How tall the cursor will be.
  ///
  /// If this property is null, RenderEditable.preferredLineHeight will be used.
  final double? cursorHeight;

  /// How thick the cursor will be.
  /// Defaults to 2.0.
  /// The cursor will draw under the text. The cursor width will extend to the right of the
  /// boundary between characters for left-to-right text and to the left for right-to-left text.
  /// This corresponds to extending downstream relative to the selected position. Negative values
  /// may be used to reverse this behavior.
  ///
  final double? cursorWidth;

  /// Whether the cursor will animate from fully transparent to fully opaque during each cursor
  /// blink.
  /// By default, the cursor opacity will animate on iOS platforms and will not animate on Android /
  /// platforms.
  ///
  final bool? cursorOpacityAnimates;

  /// The radius of the cursor.How rounded the corners of the cursor should be.
  /// By default, the cursor has no radius.
  ///
  final Radius? cursorRadius;

  /// The appearance of the keyboard.
  /// This setting is only honored on iOS devices.
  ///
  /// If unset, defaults to ThemeData.brightness.
  ///
  final Brightness? keyboardAppearance;
  /////
  @override
  final InputBorder? border;
  @override
  final BoxConstraints? prefixIconConstraints;
  @override
  final int? errorMaxLines;
  @override
  final TextStyle? errorStyle;
  @override
  final String? errorText;
  @override
  final Color? fillColor;
  @override
  final bool? filled;
  @override
  final FloatingLabelAlignment? floatingLabelAlignment;
  @override
  final FloatingLabelBehavior? floatingLabelBehavior;
  @override
  final TextStyle? floatingLabelStyle;
  @override
  final Color? focusColor;
  @override
  final InputBorder? focusedBorder;
  @override
  final InputBorder? focusedErrorBorder;
  final Widget? helper;
  @override
  final int? helperMaxLines;
  @override
  final TextStyle? helperStyle;
  @override
  final String? helperText;
  final Duration? hintFadeDuration;
  @override
  final int? hintMaxLines;
  @override
  final TextStyle? hintStyle;
  @override
  final String? hintText;
  @override
  final TextDirection? hintTextDirection;
  @override
  final Color? hoverColor;
  @override
  final Widget? icon;
  @override
  final Color? iconColor;
  final bool? isCollapse;
  @override
  final bool? isDense;
  @override
  final Widget? label;
  @override
  final TextStyle? labelStyle;
  @override
  final String? labelText;
  final bool maintainHintHeight;
  @override
  final Widget? prefix;
  @override
  final Widget? prefixIcon;
  @override
  final Color? prefixIconColor;
  @override
  final TextStyle? prefixStyle;
  @override
  final String? prefixText;
  @override
  final String? semanticCounterText;
  @override
  final Widget? suffix;
  @override
  final Widget? suffixIcon;
  @override
  final Color? suffixIconColor;
  @override
  final BoxConstraints? suffixIconConstraints;
  @override
  final TextStyle? suffixStyle;
  @override
  final String? suffixText;
  @override
  final InputBorder? enabledBorder;
  @override
  final Widget? error;
  @override
  final InputBorder? errorBorder;
  @override
  final bool? alignLabelWithHint;
  @override
  final TextStyle? counterStyle;
  @override
  final String? counterText;
  @override
  final InputBorder? disabledBorder;
  @override
  final EdgeInsetsGeometry? contentPadding;
  @override
  final Widget? counter;
  @override
  final BoxConstraints? constraints;

  const SearchInputDecoration({
    //Key? key,
    this.cursorColor = Colors.black,
    this.textCapitalization = TextCapitalization.none,
    this.searchStyle,
    this.cursorErrorColor,
    this.cursorHeight,
    this.cursorWidth = 2.0,
    this.cursorOpacityAnimates,
    this.cursorRadius,
    this.keyboardAppearance,
    this.border,
    this.prefixIconConstraints,
    this.hintMaxLines,
    this.floatingLabelStyle,
    this.errorText,
    this.error,
    this.hintTextDirection,
    this.hintFadeDuration,
    this.helper,
    this.prefixIcon,
    this.suffixIcon,
    this.suffix,
    this.label,
    this.maintainHintHeight = true,
    this.suffixIconColor,
    this.prefix,
    this.prefixIconColor,
    this.enabledBorder,
    this.focusedBorder,
    this.errorBorder,
    this.focusedErrorBorder,
    this.disabledBorder,
    this.contentPadding,
    this.hintText,
    this.hintStyle,
    this.labelText,
    this.labelStyle,
    this.prefixText,
    this.prefixStyle,
    this.suffixText,
    this.suffixStyle,
    this.counterText,
    this.counterStyle,
    this.filled,
    this.fillColor,
    this.focusColor,
    this.hoverColor,
    this.icon,
    this.iconColor,
    this.isCollapse,
    this.isDense,
    this.floatingLabelBehavior,
    this.floatingLabelAlignment,
    this.alignLabelWithHint,
    this.constraints,
    this.counter,
    this.semanticCounterText,
    this.helperText,
    this.helperStyle,
    this.helperMaxLines,
    this.errorMaxLines,
    this.errorStyle,
    this.suffixIconConstraints,
  });

  /* @override
  SearchInputDecoration copyWith({
    Color? cursorColor,
    Color? cursorErrorColor,
    double? cursorHeight,
    double? cursorWidth,
    bool? cursorOpacityAnimates,
    Radius? cursorRadius,
    Brightness? keyboardAppearance,
    TextCapitalization? textCapitalization,
    TextStyle? searchStyle,
    bool? alignLabelWithHint,
    InputBorder? border,
    BoxConstraints? constraints,
    EdgeInsetsGeometry? contentPadding,
    Widget? counter,
    TextStyle? counterStyle,
    String? counterText,
    InputBorder? disabledBorder,
    InputBorder? enabledBorder,
    Widget? error,
    InputBorder? errorBorder,
    int? errorMaxLines,
    TextStyle? errorStyle,
    String? errorText,
    Color? fillColor,
    bool? filled,
    FloatingLabelAlignment? floatingLabelAlignment,
    FloatingLabelBehavior? floatingLabelBehavior,
    TextStyle? floatingLabelStyle,
    Color? focusColor,
    InputBorder? focusedBorder,
    InputBorder? focusedErrorBorder,
    Widget? helper,
    int? helperMaxLines,
    TextStyle? helperStyle,
    String? helperText,
    Duration? hintFadeDuration,
    int? hintMaxLines,
    TextStyle? hintStyle,
    String? hintText,
    TextDirection? hintTextDirection,
    Color? hoverColor,
    Widget? icon,
    Color? iconColor,
    bool? isCollapsed,
    bool? isDense,
    Widget? label,
    TextStyle? labelStyle,
    String? labelText,
    bool? maintainHintSize, // ✅ Flutter 3.32.7
    Widget? prefix,
    Widget? prefixIcon,
    Color? prefixIconColor,
    BoxConstraints? prefixIconConstraints,
    TextStyle? prefixStyle,
    String? prefixText,
    String? semanticCounterText,
    Widget? suffix,
    Widget? suffixIcon,
    Color? suffixIconColor,
    BoxConstraints? suffixIconConstraints,
    TextStyle? suffixStyle,
    String? suffixText,
  }) {
    return SearchInputDecoration(
      cursorColor: cursorColor ?? this.cursorColor,
      cursorErrorColor: cursorErrorColor ?? this.cursorErrorColor,
      cursorHeight: cursorHeight ?? this.cursorHeight,
      cursorWidth: cursorWidth ?? this.cursorWidth,
      cursorOpacityAnimates: cursorOpacityAnimates ?? this.cursorOpacityAnimates,
      cursorRadius: cursorRadius ?? this.cursorRadius,
      keyboardAppearance: keyboardAppearance ?? this.keyboardAppearance,
      textCapitalization: textCapitalization ?? this.textCapitalization,
      searchStyle: searchStyle ?? this.searchStyle,
      alignLabelWithHint: alignLabelWithHint ?? this.alignLabelWithHint,
      border: border ?? this.border,
      constraints: constraints ?? this.constraints,
      contentPadding: contentPadding ?? this.contentPadding,
      counter: counter ?? this.counter,
      counterStyle: counterStyle ?? this.counterStyle,
      counterText: counterText ?? this.counterText,
      disabledBorder: disabledBorder ?? this.disabledBorder,
      enabledBorder: enabledBorder ?? this.enabledBorder,
      error: error ?? this.error,
      errorBorder: errorBorder ?? this.errorBorder,
      errorMaxLines: errorMaxLines ?? this.errorMaxLines,
      errorStyle: errorStyle ?? this.errorStyle,
      errorText: errorText ?? this.errorText,
      fillColor: fillColor ?? this.fillColor,
      filled: filled ?? this.filled,
      floatingLabelAlignment: floatingLabelAlignment ?? this.floatingLabelAlignment,
      floatingLabelBehavior: floatingLabelBehavior ?? this.floatingLabelBehavior,
      floatingLabelStyle: floatingLabelStyle ?? this.floatingLabelStyle,
      focusColor: focusColor ?? this.focusColor,
      focusedBorder: focusedBorder ?? this.focusedBorder,
      focusedErrorBorder: focusedErrorBorder ?? this.focusedErrorBorder,
      helper: helper ?? this.helper,
      helperMaxLines: helperMaxLines ?? this.helperMaxLines,
      helperStyle: helperStyle ?? this.helperStyle,
      helperText: helperText ?? this.helperText,
      hintFadeDuration: hintFadeDuration ?? this.hintFadeDuration,
      hintMaxLines: hintMaxLines ?? this.hintMaxLines,
      hintStyle: hintStyle ?? this.hintStyle,
      hintText: hintText ?? this.hintText,
      hintTextDirection: hintTextDirection ?? this.hintTextDirection,
      hoverColor: hoverColor ?? this.hoverColor,
      icon: icon ?? this.icon,
      iconColor: iconColor ?? this.iconColor,
      isCollapse: isCollapsed ?? this.isCollapse,
      isDense: isDense ?? this.isDense,
      label: label ?? this.label,
      labelStyle: labelStyle ?? this.labelStyle,
      labelText: labelText ?? this.labelText,
      maintainHintSize: maintainHintSize ?? this.maintainHintSize, // ✅ Important
      prefix: prefix ?? this.prefix,
      prefixIcon: prefixIcon ?? this.prefixIcon,
      prefixIconColor: prefixIconColor ?? this.prefixIconColor,
      prefixIconConstraints: prefixIconConstraints ?? this.prefixIconConstraints,
      prefixStyle: prefixStyle ?? this.prefixStyle,
      prefixText: prefixText ?? this.prefixText,
      semanticCounterText: semanticCounterText ?? this.semanticCounterText,
      suffix: suffix ?? this.suffix,
      suffixIcon: suffixIcon ?? this.suffixIcon,
      suffixIconColor: suffixIconColor ?? this.suffixIconColor,
      suffixIconConstraints: suffixIconConstraints ?? this.suffixIconConstraints,
      suffixStyle: suffixStyle ?? this.suffixStyle,
      suffixText: suffixText ?? this.suffixText,
    );
  } */

  @override
  SearchInputDecoration copyWith({
    Widget? icon,
    Color? iconColor,
    Widget? label,
    String? labelText,
    TextStyle? labelStyle,
    TextStyle? floatingLabelStyle,
    Widget? helper,
    String? helperText,
    TextStyle? helperStyle,
    int? helperMaxLines,
    String? hintText,
    Widget? hint,
    TextStyle? hintStyle,
    TextDirection? hintTextDirection,
    Duration? hintFadeDuration,
    int? hintMaxLines,
    bool? maintainHintHeight,
    bool? maintainHintSize,
    Widget? error,
    String? errorText,
    TextStyle? errorStyle,
    int? errorMaxLines,
    FloatingLabelBehavior? floatingLabelBehavior,
    FloatingLabelAlignment? floatingLabelAlignment,
    bool? isCollapsed,
    bool? isDense,
    EdgeInsetsGeometry? contentPadding,
    Widget? prefixIcon,
    Widget? prefix,
    String? prefixText,
    BoxConstraints? prefixIconConstraints,
    TextStyle? prefixStyle,
    Color? prefixIconColor,
    Widget? suffixIcon,
    Widget? suffix,
    String? suffixText,
    TextStyle? suffixStyle,
    Color? suffixIconColor,
    BoxConstraints? suffixIconConstraints,
    Widget? counter,
    String? counterText,
    TextStyle? counterStyle,
    bool? filled,
    Color? fillColor,
    Color? focusColor,
    Color? hoverColor,
    InputBorder? errorBorder,
    InputBorder? focusedBorder,
    InputBorder? focusedErrorBorder,
    InputBorder? disabledBorder,
    InputBorder? enabledBorder,
    InputBorder? border,
    bool? enabled,
    String? semanticCounterText,
    bool? alignLabelWithHint,
    BoxConstraints? constraints,
  }) {
    return SearchInputDecoration(
      icon: icon ?? this.icon,
      iconColor: iconColor ?? this.iconColor,
      label: label ?? this.label,
      labelText: labelText ?? this.labelText,
      labelStyle: labelStyle ?? this.labelStyle,
      floatingLabelStyle: floatingLabelStyle ?? this.floatingLabelStyle,
      helper: helper ?? this.helper,
      helperText: helperText ?? this.helperText,
      helperStyle: helperStyle ?? this.helperStyle,
      helperMaxLines: helperMaxLines ?? this.helperMaxLines,
      hintText: hintText ?? this.hintText,
      hintStyle: hintStyle ?? this.hintStyle,
      hintTextDirection: hintTextDirection ?? this.hintTextDirection,
      hintMaxLines: hintMaxLines ?? this.hintMaxLines,
      hintFadeDuration: hintFadeDuration ?? this.hintFadeDuration,
      maintainHintHeight: maintainHintHeight ?? this.maintainHintHeight,
      error: error ?? this.error,
      errorText: errorText ?? this.errorText,
      errorStyle: errorStyle ?? this.errorStyle,
      errorMaxLines: errorMaxLines ?? this.errorMaxLines,
      floatingLabelBehavior:
          floatingLabelBehavior ?? this.floatingLabelBehavior,
      floatingLabelAlignment:
          floatingLabelAlignment ?? this.floatingLabelAlignment,
      isDense: isDense ?? this.isDense,
      contentPadding: contentPadding ?? this.contentPadding,
      prefixIcon: prefixIcon ?? this.prefixIcon,
      prefix: prefix ?? this.prefix,
      prefixText: prefixText ?? this.prefixText,
      prefixStyle: prefixStyle ?? this.prefixStyle,
      prefixIconColor: prefixIconColor ?? this.prefixIconColor,
      prefixIconConstraints:
          prefixIconConstraints ?? this.prefixIconConstraints,
      suffixIcon: suffixIcon ?? this.suffixIcon,
      suffix: suffix ?? this.suffix,
      suffixText: suffixText ?? this.suffixText,
      suffixStyle: suffixStyle ?? this.suffixStyle,
      suffixIconColor: suffixIconColor ?? this.suffixIconColor,
      suffixIconConstraints:
          suffixIconConstraints ?? this.suffixIconConstraints,
      counter: counter ?? this.counter,
      counterText: counterText ?? this.counterText,
      counterStyle: counterStyle ?? this.counterStyle,
      filled: filled ?? this.filled,
      fillColor: fillColor ?? this.fillColor,
      focusColor: focusColor ?? this.focusColor,
      hoverColor: hoverColor ?? this.hoverColor,
      errorBorder: errorBorder ?? this.errorBorder,
      focusedBorder: focusedBorder ?? this.focusedBorder,
      focusedErrorBorder: focusedErrorBorder ?? this.focusedErrorBorder,
      disabledBorder: disabledBorder ?? this.disabledBorder,
      enabledBorder: enabledBorder ?? this.enabledBorder,
      border: border ?? this.border,
      semanticCounterText: semanticCounterText ?? this.semanticCounterText,
      alignLabelWithHint: alignLabelWithHint ?? this.alignLabelWithHint,
      constraints: constraints ?? this.constraints,
    );
  }
}
