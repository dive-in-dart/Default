import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:flutter/material.dart';
import 'package:resource_set_project/Configuration/app_config.dart';
import 'package:resource_set_project/Extension_Enum/greek_enum.dart';
import 'package:resource_set_project/Utilities/greek_textstyle.dart';

class GreekDialogPopupView {
  //=====================================================================
  ///
  /// Show Awesome Dialog with custome message
  //
  /// message - Custome message
  ///
  //=====================================================================
  static awesomeMessageDialog({
    required BuildContext context,
    required String msg,
    required DialogType dialogType,
    required ValueChanged<BuildContext> onPressed,
  }) {
    final dialogWidth = (AppConfig().currentPlatform == AppPlatform.web)
        ? (MediaQuery.of(context).size.width / 4)
        : null;
    AwesomeDialog(
      width: dialogWidth,
      animType: AnimType.scale,
      dialogType: dialogType,
      dismissOnBackKeyPress: false,
      context: context,
      title: AppConfig().appName,
      desc: msg,
      titleTextStyle: GreekTextStyle.headline20,
      descTextStyle: GreekTextStyle.headline20,
      btnOkText: 'OK',
      btnOkOnPress: () => onPressed(context),
      btnOkColor: Colors.lightBlue.shade600,
    ).show();
  }
  //=====================================================================

//=====================================================================

  //======================Reports Filter Dialogue========================

  static reportsFilterDialogs(
      {required BuildContext context, required Widget view, double? width}) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          content: Container(
              width: width,
              padding: const EdgeInsets.all(2),
              height: 550,
              child: view),
          contentPadding: EdgeInsets.zero,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(5.0)),
          ),
        );
      },
    );
  }

  static groupMasterDialogue(
      {required BuildContext context, required Widget view, double? width}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          content: Container(
              width: width,
              padding: const EdgeInsets.all(2),
              height: 550,
              child: view),
          contentPadding: EdgeInsets.zero,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(5.0)),
          ),
        );
      },
    );
  }

  //=====================================================================
  ///
  /// Show Awesome Dialog with custome message
  //
  /// message - Custome message
  ///
  //=====================================================================
  static pmsCompanyNameDialog(
      {required BuildContext context, required Widget view, double? width}) {
    AwesomeDialog(
      width: width,
      animType: AnimType.scale,
      dialogType: DialogType.noHeader,
      dismissOnBackKeyPress: true,
      context: context,
      body: view,
      titleTextStyle: GreekTextStyle.headline20,
      descTextStyle: GreekTextStyle.headline20,
    ).show();
  }

  //=====================================================================

  static onlyTitleDialogue(BuildContext context, String title) {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        Future.delayed(const Duration(milliseconds: 1000), () {
          Navigator.of(context).pop(true);
        });
        return AlertDialog(
          title: Center(child: Text(title)),
          contentPadding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15.0)),
          ),
        );
      },
    );
  }
  //=================Lengthy title=================================

  static guideTitleDialogue(
    BuildContext context,
    String title,
    String detail,
  ) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          contentPadding: const EdgeInsets.fromLTRB(10.0, 0.0, 10.0, 10.0),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15.0)),
          ),
          content: SizedBox(
            height: 90,
            width: 360,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  title,
                  style: GreekTextStyle.black_bold_18,
                ),
                const SizedBox(height: 15),
                Text(
                  detail,
                  style: GreekTextStyle.black_bold_18,
                )
              ],
            ),
          ),
          actions: [
            InkWell(
              onDoubleTap: () {},
              onLongPress: () {},
              onTap: () {
                Navigator.of(context).pop(true);
              },
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Colors.blue),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'OK',
                  style: GreekTextStyle.blue_16,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  //=====================================================================  //===================  Discard Dialogue  =====================================

  static discardDialogue(BuildContext context,
      {required Function()? onDiscard, required Function()? onCancel}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          contentPadding: const EdgeInsets.fromLTRB(20.0, 15.0, 15.0, 20.0),
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(15.0)),
          ),
          content: const SizedBox(
            height: 90,
            width: 360,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "Discard Changes",
                  style: GreekTextStyle.black_bold_18,
                ),
                SizedBox(height: 15),
                Text(
                  "Are you sure you want to discard the changes?",
                  style: GreekTextStyle.black_bold_14,
                )
              ],
            ),
          ),
          actions: [
            InkWell(
              onTap: onCancel,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Colors.grey.shade400),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Cancel',
                  style: GreekTextStyle.black_bold_14,
                ),
              ),
            ),
            const SizedBox(width: 40),
            InkWell(
              onTap: onDiscard,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 12, horizontal: 20),
                decoration: BoxDecoration(
                  border: Border.all(width: 1, color: Colors.blue),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  'Discard',
                  style: GreekTextStyle.blue_bold_14,
                ),
              ),
            ),
            const SizedBox(width: 20),
          ],
        );
      },
    );
  }

  //=====================================================================

  static messageDialogue(
      {required BuildContext context,
      required String message,
      required TextStyle? textStyle,
      required String statusCode,
      required void Function()? onTap}) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Text(message, style: textStyle),
          actions: [
            InkWell(
              onTap: onTap,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                        width: 1,
                        color:
                            (statusCode == '200') ? Colors.green : Colors.red)),
                child: Text(
                  'OK',
                  style: (statusCode == '200')
                      ? GreekTextStyle.green_medium_14
                      : GreekTextStyle.red_medium_14,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
  //=====================================================================
}
