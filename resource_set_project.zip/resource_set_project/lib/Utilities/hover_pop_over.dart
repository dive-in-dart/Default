import 'package:flutter/material.dart';
import 'package:popover/popover.dart';
import 'package:rxdart/rxdart.dart';

class HoverPopOverDialog extends StatelessWidget {
  final Widget widgetList;
  final Widget view;
  final double? width;
  final double? height;
  final BehaviorSubject<bool>? hoveringg;
  final PopoverDirection? popoverDirection;
  const HoverPopOverDialog(
      {super.key,
      required this.widgetList,
      required this.view,
      this.width,
      this.height,
      this.hoveringg,
      this.popoverDirection});

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      cursor: SystemMouseCursors.click,
      onEnter: (event) {
        hoveringg?.sink.add(true);
        showPopover(
          context: context,
          transitionDuration: const Duration(milliseconds: 150),
          bodyBuilder: (context) => widgetList,
          direction: popoverDirection ?? PopoverDirection.right,
          width: (width == null) ? 130 : width,
          height: (height == null) ? 60 : height,
          arrowHeight: 15,
          arrowWidth: 30,
          barrierColor: Colors.transparent,
        );
      },
      onExit: (event) {
        hoveringg?.sink.add(true);
      },
      child: view,
    );
  }
}
