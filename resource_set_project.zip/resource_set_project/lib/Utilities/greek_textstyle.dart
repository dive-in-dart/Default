// ignore_for_file: unused_field, constant_identifier_names

import 'package:flutter/material.dart';
import 'package:resource_set_project/Helper/constant_colors.dart';

class GreekTextStyle {
  static const _fontFamilyCenturyGothic = 'CenturyGothic';

  static const _fontFamilySegoeUI = 'SegoeUI';

  static const _fontFamilyLato = 'Lato';

  static const _fontFamilyRoboto = 'Roboto';

  static const _font9 = 9.0;

  static const _font10 = 10.0;

  static const _font11 = 11.0;

  static const _font12 = 12.0;

  static const _font13 = 13.0;

  static const _font14 = 14.0;

  static const _font15 = 15.0;

  static const _font16 = 16.0;

  static const _font17 = 17.0;

  static const _font18 = 18.0;

  static const _font19 = 19.0;

  static const _font20 = 20.0;

  static const _font21 = 21.0;

  static const _font22 = 22.0;

  static const _font23 = 23.0;

  static const _font24 = 24.0;

  static const _font25 = 25.0;

  static const _font30 = 30.0;

  //=====================================================================

  ///

  /// For greek Back Office Report PMS

  ///

  //=====================================================================

  static const normal_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF8D8D8D),
    fontSize: _font12,
    fontWeight: FontWeight.normal,
  );

  static const black_normal_15 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF31394D),
    fontSize: _font15,
    fontWeight: FontWeight.normal,
  );

  static const blue_grey_normal_15 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF748AA1),
    fontSize: _font15,
    fontWeight: FontWeight.normal,
  );

  static const blue_grey_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF748AA1),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );
  static const grey_bold_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.grey,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
  );
  static const grey_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.grey,
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const grey_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF748AA1),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );

  static const light_grey_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF7A9597),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );

  static const light_grey_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF7A9597),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );
  static const black_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );
  static const black_bold_25 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font25,
    fontWeight: FontWeight.bold,
  );

  static const black_medium_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font18,
    fontWeight: FontWeight.w500,
  );

  static const black_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );

  static const black_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
    height: 21 / 16, // Line height ratio ≈ 1.31
    letterSpacing: 0.0,
  );

  static const black_medium_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font12,
    fontWeight: FontWeight.w500,
  );

  static const blue_medium_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.blue,
    fontSize: _font12,
    fontWeight: FontWeight.w500,
  );

  static const blue_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.blue,
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );
  static const blue_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.blue,
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );

  static const white_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );
  static const white_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );
  static const white_medium_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font12,
    fontWeight: FontWeight.w500,
  );

  static const red_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF9330A),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );
  static const dark_yellow_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFFA561),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );
  static const dark_yellow_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFFA561),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );
  static const yellow_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFD6AC00),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );
  static const yellow_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFD6AC00),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );
  static const red_medium_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF9330A),
    fontSize: _font12,
    fontWeight: FontWeight.w500,
  );

  static const red_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF9330A),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );

  static const green_medium_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font14,
    fontWeight: FontWeight.w500,
  );

  static const green_medium_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font16,
    fontWeight: FontWeight.w500,
  );

  static const black_regular_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font12,
    fontWeight: FontWeight.normal,
  );
  static const black_regular_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.normal,
  );
  static const black_regular_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );
  static const black_regular_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const black_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );
  static const black_bold_14_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF363B46),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const black_bold_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const black_bold_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );

  static const normal_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF363B46),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const white_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const white_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );
  static const white_bold_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Colors.white,
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );

  static const bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const blue_bold_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const blue_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const blue_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );
  static const blue_bold_12 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font12,
    fontWeight: FontWeight.bold,
  );

  static const red_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF94A4A),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const blue_bold_20 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font20,
    fontWeight: FontWeight.bold,
  );

  static const green_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const green_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const red_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF94A4A),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const red_normal_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,

    color: Color(0xFFF94A4A),

    fontSize: _font16,

    // fontWeight: FontWeight.normal,

    fontWeight: FontWeight.w500,
  );
  static const red_regular_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF94A4A),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const red_bold_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,

    color: Color(0xFFF94A4A),

    fontSize: _font16,

    // fontWeight: FontWeight.normal,

    fontWeight: FontWeight.w500,
  );

  static const normal_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const normal_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.normal,
  );

  static const blue_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const bold_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const regular_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF343434),
    fontSize: _font14,
    fontWeight: FontWeight.normal,
  );

  static const grey_bold_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF757575),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const grey_normal_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color.fromRGBO(238, 238, 238, 1),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const grey_bold_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color.fromARGB(255, 117, 117, 117),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );
  static const grey_medium_18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF858585),
    fontSize: _font18,
    fontWeight: FontWeight.w500,
  );

  static const black_bold_22 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font22,
    fontWeight: FontWeight.bold,
  );

  static const login_title_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF3A3A3A),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const login_title_welcome = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF58634),
    fontSize: _font20,
    fontWeight: FontWeight.bold,
  );

  static const forgot_button_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF747474),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const login_button_txt = TextStyle(
    fontFamily: _fontFamilySegoeUI,
    color: Color(0xFF1490E4),
    fontWeight: FontWeight.bold,
    fontSize: _font22,
  );

  static const register_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF58634),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const broker_id_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const broker_id_txt_pms = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF333333),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const reset_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const profile_previous_value_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const white_normal_16 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font16,
    fontWeight: FontWeight.normal,
    color: ConstantColors.whiteColor,
  );

  static const ledger_report_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font15,
    fontWeight: FontWeight.normal,
  );

  static const ledger_report_dropdown = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font12,
    fontWeight: FontWeight.normal,
  );

  static const profile_txt_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font21,
    fontWeight: FontWeight.normal,
  );

  static const profile_txt_3 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font17,
    fontWeight: FontWeight.normal,
  );

  static const dashboard_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF808080),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const report_filter_menu_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF808080),
    fontSize: _font14,
    fontWeight: FontWeight.normal,
  );

  static const profile_pnl_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF48022),
    fontSize: _font20,
    fontWeight: FontWeight.normal,
  );

  static const profile_previous_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF747474),
    fontSize: _font15,
    fontWeight: FontWeight.bold,
  );

  static const profile_view_more = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const client_name_pms = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF707070),
    fontSize: _font17,
    fontWeight: FontWeight.normal,
  );

/////////////////

  ///  web

  static const green_bold_22 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font22,
    fontWeight: FontWeight.bold,
  );
  static const red_bold_22 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF9330A),
    fontSize: _font22,
    fontWeight: FontWeight.bold,
  );
  static const green_bold_25 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF36AA49),
    fontSize: _font25,
    fontWeight: FontWeight.bold,
  );
  static const red_bold_25 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF9330A),
    fontSize: _font25,
    fontWeight: FontWeight.bold,
  );

  static const web_login_title_welcome = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF58634),
    fontSize: _font25,
    fontWeight: FontWeight.bold,
  );

  static const web_login_forget_password = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
    fontWeight: FontWeight.bold,
    color: Color(0xFF1592E6),
  );

  static const web_ledger_report_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const web_dashboard_option_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF272727),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const web_report_filter_date_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF3E3E3E),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const web_report_apply_filter_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFCFCFC),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const web_report_save_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFCFCFC),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const web_report_filter_column_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0161C1),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const web_dashboard_menu_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF5E5E5E),
    fontSize: _font20,
    fontWeight: FontWeight.normal,
  );

  //=====================================================================

  //=====================================================================

  ///

  /// Fro greek license project

  ///

  //=====================================================================

  //----------------- Login -----------------//

  static const loginProceedButtonTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font23,
    fontWeight: FontWeight.bold,
    color: ConstantColors.whiteColor,
  );

  static const loginProceedButtonTextStyle_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font20,
    fontWeight: FontWeight.bold,
    color: ConstantColors.whiteColor,
  );

  static const loginHintTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,

    fontSize: null, //23.0,

    fontWeight: FontWeight.normal,

    color: ConstantColors.loginHintTextColor,
  );

  static const loginHintTextStyle_2 = TextStyle(
    fontFamily: _fontFamilyRoboto,

    fontSize: null, //23.0,

    fontWeight: FontWeight.normal,

    color: ConstantColors.loginHintTextColor_2,
  );

  static const loginTextFieldTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,

    fontSize: null, //23.0,

    fontWeight: FontWeight.normal,

    color: ConstantColors.loginTextColor,
  );

  //------------------ END ------------------//

  //----------------- License Page -----------------//

  static const headerColumnBlack = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color.fromARGB(255, 111, 110, 110),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  //  For Table

  static const tableColumnHeadingTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: Color.fromRGBO(114, 114, 114, 1.0),
  );

  static const tableCellTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,

    fontSize: _font14,

    fontWeight: FontWeight.bold,

    color: Color(0xFF363B46),

    // color: Color.fromRGBO(114, 114, 114, 1.0),
  );

  static const tableCellTextStylePositive = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font14,
    fontWeight: FontWeight.bold,
    color: Color.fromARGB(255, 45, 113, 192),
  );

  static const tableCellSelectedTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: Color(0xFF1592E6),
  );

  static const tableCellUnselectedTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font13,
    fontWeight: FontWeight.bold,
    color: Color.fromRGBO(114, 114, 114, 1.0),
  );

  //------------------- END -------------------//

  // -------------Request List Page Web ------------//

  static const requestListDate_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF444444),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const label_floating = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const pms_tab_selected = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF48022),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const orange_bold_14 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFF48022),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const pms_dashboard_assetname = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF272830),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  static const pms_select_company_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF272830),
    fontSize: _font18,
    fontWeight: FontWeight.bold,
  );

  static const pms_dashboard_graph_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF272830),
    fontSize: _font16,
    fontWeight: FontWeight.normal,
  );

  static const unselected_report = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF9B9B9B),
    fontSize: _font18,
    fontWeight: FontWeight.normal,
  );

  // static const dashboard_option_txt = TextStyle(

  //   fontFamily: _fontFamilyRoboto,

  //   color: Color(0xFF272727),

  //   fontSize: _font13,

  //   fontWeight: FontWeight.normal,

  // );

  static const profile_txt_4 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF272727),
    fontSize: _font16,
    fontWeight: FontWeight.bold,
  );

  static const debitText = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFF0000),
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const pms_drawer_txt = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontSize: _font18,
    fontWeight: FontWeight.normal,
    color: Color(0xFF171725),
  );

  //=====================================================================

  // ======================================

  //  For License project mobile view

  // =====================================

  static const mobileLicenseGoBack = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFF0472B3),
    fontSize: _font15,
    fontWeight: FontWeight.bold,
  );

  static const errorTextStyle = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: Color(0xFFFF0000),
    fontSize: _font12,
    fontWeight: FontWeight.normal,
  );

  static const heading18 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.blackColor,
    fontSize: _font16,
  );

  static const headline20 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    color: ConstantColors.blackColor,
    fontWeight: FontWeight.normal,
    fontSize: _font18,
  );

  static const heading11 = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.bold,
    color: ConstantColors.whiteColor,
    fontSize: _font18,
  );

  // ========================For Buttons============

  static const enableBtn = TextStyle(
    fontFamily: _fontFamilyRoboto,
    fontWeight: FontWeight.w400,
    color: ConstantColors.blueColor,
    fontSize: _font18,
  );

  static const commonStyle = TextStyle(
    color: Colors.black,
    fontSize: _font14,
    fontWeight: FontWeight.bold,
  );

  static const filterStyle = TextStyle(
      color: Color.fromARGB(255, 117, 117, 117),
      fontWeight: FontWeight.bold,
      fontSize: 12);

  static const normalText = TextStyle(
    fontFamily: _fontFamilyRoboto,

    // color: Color(0xFF343434),

    // color: Colors.black,

    fontSize: _font15,

    fontWeight: FontWeight.normal,
  );

  //========================================///

  static const robot_medium_18b = TextStyle(
    fontFamily: _fontFamilyRoboto,

    // color: Color(0xFF343434),

    // color: Colors.black,

    fontSize: _font15,

    fontWeight: FontWeight.normal,
  );
}

//=====================================================================

