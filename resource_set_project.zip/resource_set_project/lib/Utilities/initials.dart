String getInitials(String name) {
  final trimmed = name.trim();
  if (trimmed.isEmpty) return '';
  return trimmed.length >= 2
      ? trimmed.substring(0, 2).toUpperCase()
      : trimmed.toUpperCase();
}
