class ReloadMobile {
  ///To save the pdf file in the device
  reloadWeb() async {}
}
