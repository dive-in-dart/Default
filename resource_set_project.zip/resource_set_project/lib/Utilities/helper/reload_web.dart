// ignore_for_file: avoid_web_libraries_in_flutter

// ignore: unused_import
import 'dart:html' as html;

class ReloadWeb {
  ///To save the pdf file in the device
  reloadWeb() async {
    html.window.location.reload();
  }
}
