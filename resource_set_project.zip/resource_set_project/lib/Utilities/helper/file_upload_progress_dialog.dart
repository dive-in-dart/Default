import 'package:flutter/material.dart';

class FileUploadLoaderDialog extends StatelessWidget {
  final int uploadedCount;
  final int totalFiles;
  final String currentFileName;

  const FileUploadLoaderDialog({
    super.key,
    required this.uploadedCount,
    required this.totalFiles,
    required this.currentFileName,
  });

  @override
  Widget build(BuildContext context) {
    final double progress = totalFiles == 0 ? 0 : uploadedCount / totalFiles;

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: const Color(0xFFF6FAFF), // pastel blue
          borderRadius: BorderRadius.circular(14),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            /// Title
            const Row(
              children: [
                Icon(Icons.folder_copy_outlined, color: Color(0xFF6B8DE3)),
                SizedBox(width: 8),
                Text(
                  "Uploading Files",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            /// Progress Bar
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                backgroundColor: const Color(0xFFE6EEFB),
                valueColor: const AlwaysStoppedAnimation(
                  Color(0xFF8AAAE5), // pastel blue
                ),
              ),
            ),

            const SizedBox(height: 2),
            const LinearProgressIndicator(
              // value: progress,
              minHeight: 1,
              backgroundColor: Color(0xFFE6EEFB),
              valueColor: AlwaysStoppedAnimation(
                Color(0xFF8AAAE5), // pastel blue
              ),
            ),
            const SizedBox(height: 16),

            /// Progress Text
            Text(
              "$uploadedCount of $totalFiles uploaded",
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: Color(0xFF5C6B7A),
              ),
            ),

            const SizedBox(height: 6),

            /// Current File
            Text(
              currentFileName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF8A97A5),
              ),
            ),

            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }
}
