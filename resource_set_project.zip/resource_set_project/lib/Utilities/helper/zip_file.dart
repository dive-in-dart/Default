// ignore_for_file: depend_on_referenced_packages

import 'dart:typed_data';
import 'package:archive/archive.dart';

class FileZipper {
  static Uint8List zipSingleFile({
    required Uint8List fileBytes,
    required String fileName,
  }) {
    final archive = Archive();

    archive.addFile(
      ArchiveFile(
        fileName,
        fileBytes.length,
        fileBytes,
      ),
    );

    final zipEncoder = ZipEncoder();
    final zippedData = zipEncoder.encode(archive);

    return Uint8List.fromList(zippedData);
  }
}
