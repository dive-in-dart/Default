class SocketResponseModel {
  String? type;
  String? loginID;
  String? message;
  List<Records>? records;
  String? status;
  int? timestamp;
  int? totalLines;

  SocketResponseModel(
      {this.type,
      this.loginID,
      this.message,
      this.records,
      this.status,
      this.timestamp,
      this.totalLines});

  SocketResponseModel.fromJson(Map<String, dynamic> json) {
    type = json['type'];
    loginID = json['loginID'];
    message = json['message'];
    if (json['records'] != null) {
      records = <Records>[];
      json['records'].forEach((v) {
        records!.add(Records.fromJson(v));
      });
    }
    status = json['status'];
    timestamp = json['timestamp'];
    totalLines = json['totalLines'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['type'] = type;
    data['loginID'] = loginID;
    data['message'] = message;
    if (records != null) {
      data['records'] = records!.map((v) => v.toJson()).toList();
    }
    data['status'] = status;
    data['timestamp'] = timestamp;
    data['totalLines'] = totalLines;
    return data;
  }
}

class Records {
  String? clientCode;
  String? errorCode;
  String? filename;
  String? loginID;
  String? message;
  String? status;
  String? timestamp;

  Records(
      {this.clientCode,
      this.errorCode,
      this.filename,
      this.loginID,
      this.message,
      this.status,
      this.timestamp});

  Records.fromJson(Map<String, dynamic> json) {
    clientCode = json['ClientCode'];
    errorCode = json['ErrorCode'];
    filename = json['Filename'];
    loginID = json['LoginID'];
    message = json['Message'];
    status = json['Status'];
    timestamp = json['Timestamp'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['ClientCode'] = clientCode;
    data['ErrorCode'] = errorCode;
    data['Filename'] = filename;
    data['LoginID'] = loginID;
    data['Message'] = message;
    data['Status'] = status;
    data['Timestamp'] = timestamp;
    return data;
  }
}
