// class ScreenIndex {
//   //=====================================================================
//   ///
//   /// For managing index statically
//   ///
//   //=====================================================================

// // screen index

//   // Dashboard
//   static const dashboarIndex = 0;
//   // Portfolio Analysis
//   static const portfolioIndex = 1;
//   static const voucherReportIndex = 2;
//   // Add Transaction
//   static const addTransIndex = 3;
//   //Account Master
//   static const accountMasterIndex = 4;
//   // financial report
//   static const balanceSheetInd = 5;
//   static const profitLostInd = 6;

//   static const cashFlowInd = 7;
//   static const ledgerReport = 8;
//   static const gainLossReport = 9;
//   static const trialBalanceReport = 10;
//   static const stockInHandReport = 11;
//   static const globalReport = 12;
//   static const dayGlobalReport = 13;
// }

class ScreenIndex {
  //=====================================================================
  ///
  /// For managing index statically
  ///
  //=====================================================================

// screen index

  // Dashboard
  static const dashboarIndex = 0;
  // Portfolio Analysis
  static const portfolioIndex = 1;
  static const voucherReportIndex = 2;
  // Add Transaction
  static const addTransIndex = 3;
  //Account Master
  static const accountMasterIndex = 4;

  // Global Reports
  static const globalReport = 5;
  static const dayGlobalReport = 6;
  static const gainLossReport = 7;
  static const stockInHandReport = 8;
  static const stockFlowReport = 9;

  // financial report
  static const balanceSheetInd = 10;
  static const balanceSheetDetailInd = 11;
  static const profitLostInd = 12;
  static const cashFlowInd = 13;
  static const trialBalanceReport = 14;
  static const ledgerReport = 15;
  static const trialBalDetailsReport = 16;
  static const investmentReturnReport = 17;
  static const corptActnReport = 18;
  static const reconcelationReport = 19;

  // New report
  static const reportA = 20;
  static const reportB = 21;
  static const reportC = 22;

  // New report
  static const viewLogs = 23;
  static const helps = 24;

  static const holdings = 25;
}
