import 'package:flutter/material.dart';
import 'package:resource_set_project/Utilities/greek_search_textfield/search_field.dart';

// ─── Constants ───────────────────────────────────────────────────────────────

const _kData = [
  'Vishakha',
  'Anuradha',
  'Jyeshtha',
  'Mula',
  'P. Ashadha',
  'U. Ashadha',
  'Shravana',
  'Dhanishta',
  'Shatabhisha',
  'P. Bhadrapada',
  'U. Bhadrapada',
  'Revati',
  'Ashwini',
  'Bharani',
  'Krittika',
  'Rohini',
  'Mrigashira',
  'Ardra',
  'Punarvasu',
  'Pushya',
  'Ashlesha',
  'Magha',
  'P. Phalguni',
  'U. Phalguni',
  'Hasta',
  'Chitra',
  'Swati',
];

const _kLabels = [
  'Janam',
  'Sampat',
  'Vipat',
  'Kshem',
  'Pratiyari',
  'Sadhak',
  'Vadh',
  'Mitra',
  'Ati-Mitra',
];

/// 🔥 Nakshatra Lord Cycle (fixed)
const _kLords = ['JU', 'SA', 'MER', 'KE', 'VE', 'SU', 'MO', 'MAR', 'RAH'];

// ─── Theme ───────────────────────────────────────────────────────────────────

class _C {
  static const background = Color(0xFFF7F6F3);
  static const surface = Color(0xFFFFFFFF);
  static const border = Color(0xFFE0DDD8);
  static const accent = Color(0xFF5B5BD6);
  static const textPrimary = Color(0xFF1A1A2E);
  static const textMuted = Color(0xFF8A8A9A);
  static const accentFaint = Color(0xFFF0EFF9);
}

// ─── App Entry ───────────────────────────────────────────────────────────────

class SimpleGrid extends StatefulWidget {
  const SimpleGrid({super.key});

  @override
  State<SimpleGrid> createState() => _SimpleGridState();
}

class _SimpleGridState extends State<SimpleGrid> {
  String? _selected;

  List<String> get _rotatedData {
    if (_selected == null) return _kData;
    final start = _kData.indexOf(_selected!);
    return [..._kData.sublist(start), ..._kData.sublist(0, start)];
  }

  @override
  Widget build(BuildContext context) {
    final display = _rotatedData;

    return Scaffold(
      backgroundColor: _C.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _Header(),
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.border),
                boxShadow: const [
                  BoxShadow(
                    color: Color(0x0A000000),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SearchField(
                suggestions: _kData.map((e) => SearchFieldListItem(e)).toList(),
                onSubmit: (value) {
                  setState(() {
                    _selected = value;
                  });
                },
                onSuggestionTap: (value) {
                  setState(() {
                    _selected = value.searchKey;
                  });
                },
                initialValue: SearchFieldListItem(_selected ?? _kData.first),
                searchInputDecoration:
                    const InputDecoration(border: InputBorder.none),
              ),
            ),
            // _DropdownCard(
            //   selected: _selected ?? _kData.first,
            //   onChanged: (v) => setState(() => _selected = v),
            // ),
            const SizedBox(height: 12),
            Expanded(child: _Grid(display: display)),
            const SizedBox(height: 8),
          ],
        ),
      ),
    );
  }
}

// ─── Header ───────────────────────────────────────────────────────────────────

class _Header extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, 16),
      child: Text(
        'Nakshatra Tara Chart',
        style: TextStyle(
          fontSize: 13,
          color: _C.textMuted,
          letterSpacing: 0.4,
        ),
      ),
    );
  }
}

// ─── Dropdown ─────────────────────────────────────────────────────────────────

class _DropdownCard extends StatelessWidget {
  final String selected;
  final ValueChanged<String?> onChanged;

  const _DropdownCard({required this.selected, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.border),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0A000000),
            blurRadius: 8,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: selected,
          hint: const Text(
            'Select a Nakshatra',
            style: TextStyle(color: _C.textMuted, fontSize: 14),
          ),
          icon:
              const Icon(Icons.unfold_more_rounded, size: 20, color: _C.accent),
          dropdownColor: _C.surface,
          borderRadius: BorderRadius.circular(12),
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: _C.textPrimary,
          ),
          items: _kData
              .map((n) => DropdownMenuItem(value: n, child: Text(n)))
              .toList(),
          onChanged: onChanged,
          menuMaxHeight: 300,
        ),
      ),
    );
  }
}

// ─── Grid ─────────────────────────────────────────────────────────────────────

class _Grid extends StatelessWidget {
  final List<String> display;
  const _Grid({required this.display});

  @override
  Widget build(BuildContext context) {
    final startIndex = _kData.indexOf(display[0]);

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        children: [
          _ColumnHeader(),
          const SizedBox(height: 4),
          Expanded(
            child: ListView.builder(
              itemCount: 9,
              physics: const BouncingScrollPhysics(),
              itemBuilder: (_, rowIndex) {
                final lord = _kLords[(startIndex + rowIndex) % 9];

                return _GridRow(
                  rowIndex: rowIndex,
                  label: _kLabels[rowIndex],
                  lord: lord,
                  cells: List.generate(
                    3,
                    (col) => display[rowIndex + col * 9],
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Column Header ────────────────────────────────────────────────────────────

class _ColumnHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(
        children: [
          const SizedBox(width: 28),
          const SizedBox(width: 6),
          const SizedBox(width: 78),
          ...['Good', 'Better', 'Best'].map(
            (h) => Expanded(
              child: Text(
                h,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: _C.textMuted,
                  letterSpacing: 0.5,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─── Grid Row ─────────────────────────────────────────────────────────────────

class _GridRow extends StatelessWidget {
  final int rowIndex;
  final String label;
  final String lord;
  final List<String> cells;

  const _GridRow({
    required this.rowIndex,
    required this.label,
    required this.lord,
    required this.cells,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 3),
      decoration: BoxDecoration(
        color: rowIndex.isEven ? _C.surface : _C.background,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.border),
      ),
      child: IntrinsicHeight(
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Sr No
            Container(
              width: 28,
              alignment: Alignment.center,
              decoration: const BoxDecoration(
                color: _C.accentFaint,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(9),
                  bottomLeft: Radius.circular(9),
                ),
              ),
              child: Text(
                '${rowIndex + 1}',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: _C.accent,
                ),
              ),
            ),

            // Label + Lord
            Container(
              width: 78,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              decoration: const BoxDecoration(
                border: Border(
                  left: BorderSide(color: _C.border),
                  right: BorderSide(color: _C.border),
                ),
              ),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: _C.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    lord,
                    style: const TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                      color: _C.textMuted,
                    ),
                  ),
                ],
              ),
            ),

            // Data cells
            ...List.generate(3, (col) {
              final isLast = col == 2;
              return Expanded(
                child: Container(
                  alignment: Alignment.center,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 10),
                  decoration: BoxDecoration(
                    border: Border(
                      right: isLast
                          ? BorderSide.none
                          : const BorderSide(color: _C.border),
                    ),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      cells[col],
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: _C.textPrimary,
                      ),
                    ),
                  ),
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
