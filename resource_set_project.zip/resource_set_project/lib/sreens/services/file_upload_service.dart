import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

class FileUploadService {
  static Future<int> uploadMultipartImage(String filename) async {
    var request =
        http.MultipartRequest('POST', Uri.parse('192.168.209.233:4446/upload'));

    try {
      request.fields['clientCode'] = 'ABC';
      request.fields['imgeType'] = 'jpeg';
      request.fields['file_path'] = filename.toString();
      request.files.add(http.MultipartFile.fromBytes(
          'imagePath', File(filename).readAsBytesSync(),
          filename: 'ABC_${filename.split("/").last}'));
    } catch (e) {
      return 1;
    }
    var res = await request.send();

    if (kDebugMode) {
      print('status code ${res.statusCode}');
    }

    if (res.statusCode == 200) {
      // await callImageRequest();
      return 0;
    } else {
      return 1;
    }
  }
}
