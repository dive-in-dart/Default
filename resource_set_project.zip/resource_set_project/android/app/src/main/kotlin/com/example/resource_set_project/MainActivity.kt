package com.example.resource_set_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
