import 'package:flutter/material.dart';

// --- CUSTOM THEME EXTENSION FOR NEUMORPHIC SHADOWS ---
class ShadowColors extends ThemeExtension<ShadowColors> {
  final Color? shadowLight;
  final Color? shadowDark;
  const ShadowColors({this.shadowLight, this.shadowDark});

  @override
  ShadowColors copyWith({Color? shadowLight, Color? shadowDark}) {
    return ShadowColors(
      shadowLight: shadowLight ?? this.shadowLight,
      shadowDark: shadowDark ?? this.shadowDark,
    );
  }

  @override
  ShadowColors lerp(ThemeExtension<ShadowColors>? other, double t) {
    if (other is! ShadowColors) return this;
    return ShadowColors(
      shadowLight: Color.lerp(shadowLight, other.shadowLight, t),
      shadowDark: Color.lerp(shadowDark, other.shadowDark, t),
    );
  }
}

// --- MAIN ENTRY WIDGET CLASS ---
class ReferenceUI extends StatefulWidget {
  const ReferenceUI({super.key});

  @override
  State<ReferenceUI> createState() => _ReferenceUIState();
}

class _ReferenceUIState extends State<ReferenceUI> {
  bool _isDarkTheme = false;

  @override
  Widget build(BuildContext context) {
    // Light Theme Palette: White & Beige & Brown
    final lightTheme = ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: const Color(0xFFF7F5F0),
      primaryColor: const Color(0xFF8B5A2B),
      cardColor: Colors.white,
      hintColor: Colors.grey,
      extensions: const <ThemeExtension<dynamic>>[
        ShadowColors(
          shadowLight: Colors.white,
          shadowDark: Color(0xD0D3CBC2),
        ),
      ],
    );

    // Dark Theme Palette: Black & Brown
    final darkTheme = ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF121212),
      primaryColor: const Color(0xFFCD853F),
      cardColor: const Color(0xFF1E1E1E),
      hintColor: Colors.grey,
      extensions: const <ThemeExtension<dynamic>>[
        ShadowColors(
          shadowLight: Color(0xFF2C2C2C),
          shadowDark: Color(0xFF090909),
        ),
      ],
    );

    return Theme(
      data: _isDarkTheme ? darkTheme : lightTheme,
      child: Scaffold(
        body: const ECommerceScreen(),
        floatingActionButton: FloatingActionButton(
          backgroundColor:
              _isDarkTheme ? const Color(0xFFCD853F) : const Color(0xFF8B5A2B),
          child: Icon(_isDarkTheme ? Icons.light_mode : Icons.dark_mode,
              color: Colors.white),
          onPressed: () => setState(() => _isDarkTheme = !_isDarkTheme),
        ),
      ),
    );
  }
}

// --- SCREEN 1: E-COMMERCE MAIN DASHBOARD ---
class ECommerceScreen extends StatefulWidget {
  const ECommerceScreen({super.key});

  @override
  State<ECommerceScreen> createState() => _ECommerceScreenState();
}

class _ECommerceScreenState extends State<ECommerceScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _entryController;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    // Controlled transition timeline
    _entryController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0.0, 0.3), // Lower down exit point
      end: Offset.zero,
    ).animate(CurvedAnimation(
        parent: _entryController, curve: Curves.fastLinearToSlowEaseIn));

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _entryController, curve: Curves.easeIn),
    );

    _entryController.forward();
  }

  @override
  void dispose() {
    _entryController.dispose();
    super.dispose();
  }

  void _navigateToCart(BuildContext context) {
    Navigator.push(
      context,
      PageRouteBuilder(
        transitionDuration: const Duration(milliseconds: 800),
        reverseTransitionDuration: const Duration(milliseconds: 600),
        pageBuilder: (context, animation, secondaryAnimation) =>
            const CartCheckoutScreen(),
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final slide =
              Tween<Offset>(begin: const Offset(0.0, 1.0), end: Offset.zero)
                  .animate(
            CurvedAnimation(
                parent: animation, curve: Curves.fastLinearToSlowEaseIn),
          );
          return SlideTransition(position: slide, child: child);
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return SafeArea(
      child: SlideTransition(
        position: _slideAnimation,
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Premium Espresso',
                            style: TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: theme.primaryColor)),
                        const SizedBox(height: 4),
                        Text('Handpicked Coffee Beans',
                            style: TextStyle(
                                fontSize: 14, color: theme.hintColor)),
                      ],
                    ),
                    HoverScaleButton(
                      onTap: () => _navigateToCart(context),
                      child: ThreeDContainer(
                        padding: const EdgeInsets.all(12),
                        borderRadius: BorderRadius.circular(12),
                        child: Icon(Icons.shopping_bag_outlined,
                            color: theme.primaryColor),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30),
                ThreeDContainer(
                  padding: const EdgeInsets.all(16),
                  borderRadius: BorderRadius.circular(24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ThreeDContainer(
                        height: 200,
                        width: double.infinity,
                        borderRadius: BorderRadius.circular(16),
                        child: Center(
                          child: Icon(Icons.coffee_maker,
                              size: 80,
                              color: theme.primaryColor.withOpacity(0.7)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      const Text('Arabica Dark Roast',
                          style: TextStyle(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Text(
                        'Experience a deep, rich aroma with undertones of dark chocolate and woody spice notes.',
                        style: TextStyle(color: theme.hintColor, fontSize: 13),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text('\$24.99',
                              style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                  color: theme.primaryColor)),
                          HoverScaleButton(
                            onTap: () => _navigateToCart(context),
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 24, vertical: 12),
                              decoration: BoxDecoration(
                                color: theme.primaryColor,
                                borderRadius: BorderRadius.circular(14),
                              ),
                              child: const Text('Buy Now',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// --- SCREEN 2: CART & CHECKOUT BREAKDOWN ---
class CartCheckoutScreen extends StatelessWidget {
  const CartCheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  HoverScaleButton(
                    onTap: () => Navigator.pop(context),
                    child: ThreeDContainer(
                      padding: const EdgeInsets.all(10),
                      borderRadius: BorderRadius.circular(12),
                      child: Icon(Icons.arrow_back_ios_new,
                          size: 18, color: theme.primaryColor),
                    ),
                  ),
                  const SizedBox(width: 20),
                  const Text('Checkout',
                      style:
                          TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                ],
              ),
              const SizedBox(height: 25),
              Expanded(
                child: ListView(
                  physics: const BouncingScrollPhysics(),
                  children: [
                    Text('Selected Items',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: theme.hintColor)),
                    const SizedBox(height: 10),
                    ThreeDContainer(
                      padding: const EdgeInsets.all(12),
                      borderRadius: BorderRadius.circular(16),
                      child: Row(
                        children: [
                          Container(
                            height: 60,
                            width: 60,
                            decoration: BoxDecoration(
                                color: theme.primaryColor.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12)),
                            child:
                                Icon(Icons.coffee, color: theme.primaryColor),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('Arabica Dark Roast',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 16)),
                                Text('Quantity: 1',
                                    style: TextStyle(
                                        color: theme.hintColor, fontSize: 13)),
                              ],
                            ),
                          ),
                          Text('\$24.99',
                              style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  color: theme.primaryColor)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),
                    Text('Shipping Address',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: theme.hintColor)),
                    const SizedBox(height: 10),
                    ThreeDContainer(
                      padding: const EdgeInsets.all(16),
                      borderRadius: BorderRadius.circular(16),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.location_on_outlined,
                              color: theme.primaryColor),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Text('John Doe',
                                    style: TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 15)),
                                const SizedBox(height: 4),
                                Text(
                                    '123 Brew Lane, Coffee District,\nManhattan, NY 10001',
                                    style: TextStyle(
                                        color: theme.hintColor,
                                        fontSize: 13,
                                        height: 1.4)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),
                    Text('Payment Method',
                        style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: theme.hintColor)),
                    const SizedBox(height: 10),
                    ThreeDContainer(
                      padding: const EdgeInsets.all(16),
                      borderRadius: BorderRadius.circular(16),
                      child: Row(
                        children: [
                          Icon(Icons.credit_card, color: theme.primaryColor),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Text('•••• •••• •••• 4582',
                                style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    fontSize: 15,
                                    letterSpacing: 1.5)),
                          ),
                          Text('Edit',
                              style: TextStyle(
                                  color: theme.primaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 13)),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    ThreeDContainer(
                      padding: const EdgeInsets.all(16),
                      borderRadius: BorderRadius.circular(20),
                      child: Column(
                        children: [
                          _buildSummaryRow('Subtotal', '\$24.99', theme),
                          const SizedBox(height: 10),
                          _buildSummaryRow('Delivery Fee', '\$3.50', theme),
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 12),
                            child: Divider(height: 1, thickness: 0.5),
                          ),
                          _buildSummaryRow('Total Amount', '\$28.49', theme,
                              isTotal: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 35),
                    HoverScaleButton(
                      onTap: () {},
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        decoration: BoxDecoration(
                          color: theme.primaryColor,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: const Center(
                          child: Text('Confirm Order',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSummaryRow(String label, String value, ThemeData theme,
      {bool isTotal = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label,
            style: TextStyle(
                fontSize: isTotal ? 16 : 14,
                fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
                color: isTotal ? null : theme.hintColor)),
        Text(value,
            style: TextStyle(
                fontSize: isTotal ? 18 : 14,
                fontWeight: FontWeight.bold,
                color: isTotal ? theme.primaryColor : null)),
      ],
    );
  }
}

// --- UTILITY 3D NEUMORPHIC CONTAINER ---

class ThreeDContainer extends StatelessWidget {
  final Widget child;
  final double? height;
  final double? width;
  final EdgeInsetsGeometry? padding;
  final BorderRadius borderRadius;

  const ThreeDContainer({
    super.key,
    required this.child,
    this.height,
    this.width,
    this.padding,
    required this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // FIX 1: Explicitly ask for <ShadowColors> type
    final shadows = theme.extension<ShadowColors>();

    // FIX 2: Define safe default fallback colors if the extension isn't found
    final isLight = theme.brightness == Brightness.light;
    final fallbackLight = isLight ? Colors.white : const Color(0xFF2C2C2C);
    final fallbackDark =
        isLight ? const Color(0xD0D3CBC2) : const Color(0xFF090909);

    final shadowLightColor = shadows?.shadowLight ?? fallbackLight;
    final shadowDarkColor = shadows?.shadowDark ?? fallbackDark;

    return Container(
      width: width,
      height: height,
      padding: padding,
      decoration: BoxDecoration(
        color: theme.cardColor,
        borderRadius: borderRadius,
        border: Border.all(
          color: isLight
              ? Colors.white.withOpacity(0.6)
              : Colors.white.withOpacity(0.05),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: shadowLightColor, // Used fallback safe variable
            offset: const Offset(-5, -5),
            blurRadius: 10,
            spreadRadius: 1,
          ),
          BoxShadow(
            color: shadowDarkColor, // Used fallback safe variable
            offset: const Offset(5, 5),
            blurRadius: 12,
            spreadRadius: 1,
          ),
        ],
      ),
      child: child,
    );
  }
}

// --- UTILITY SMOOTH SCALE ELEMENT ---

class HoverScaleButton extends StatefulWidget {
  final Widget child;
  final VoidCallback onTap;
  const HoverScaleButton({super.key, required this.child, required this.onTap});

  @override
  State<HoverScaleButton> createState() =>
      _HoverScaleButtonState(); // Added <HoverScaleButton>
}

class _HoverScaleButtonState extends State<HoverScaleButton> {
  // Added <HoverScaleButton>
  bool _isHovered = false;

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) => setState(() => _isHovered = true), // Fixed underscore
      onExit: (_) => setState(() => _isHovered = false), // Changed () to (_)
      child: GestureDetector(
        onTapDown: (_) => setState(
            () => _isHovered = true), // Changed () to (_) and fixed underscore
        onTapUp: (_) => setState(
            () => _isHovered = false), // Changed () to (_) and fixed underscore
        onTapCancel: () =>
            setState(() => _isHovered = false), // Fixed underscore
        onTap: widget.onTap,
        child: AnimatedScale(
          scale: _isHovered ? 1.05 : 1.0,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOutCubic,
          child: widget.child,
        ),
      ),
    );
  }
}
